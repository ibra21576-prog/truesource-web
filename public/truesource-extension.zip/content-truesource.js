;(async function () {
  const { vinted_token, vinted_domain, vinted_at } = await chrome.storage.local.get([
    'vinted_token', 'vinted_domain', 'vinted_at'
  ])

  if (!vinted_token) return
  if (vinted_at && Date.now() - vinted_at > 7200000) {
    chrome.storage.local.remove(['vinted_token', 'vinted_domain', 'vinted_at'])
    return
  }

  try {
    const r = await fetch('/api/vinted-connect', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain: vinted_domain, accessToken: vinted_token }),
    })
    const data = await r.json()
    if (data.ok) {
      chrome.storage.local.remove(['vinted_token', 'vinted_domain', 'vinted_at'])
      chrome.runtime.sendMessage({ type: 'CONNECTED' })
      setTimeout(() => location.reload(), 600)
    }
  } catch (e) {}
})()
