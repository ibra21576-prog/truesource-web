const dot = document.getElementById('dot')
const statusText = document.getElementById('status-text')
const domainRow = document.getElementById('domain-row')
const domainText = document.getElementById('domain-text')
const hint = document.getElementById('hint')

chrome.storage.local.get(['vinted_token', 'vinted_domain'], (data) => {
  if (data.vinted_token) {
    dot.className = 'dot dot-yellow'
    statusText.textContent = 'Vinted erkannt — öffne Settings'
    domainRow.style.display = 'block'
    domainText.textContent = data.vinted_domain || 'vinted.de'
    hint.textContent = 'Klick auf "Open Settings" — du wirst automatisch verbunden!'
  } else {
    dot.className = 'dot dot-grey'
    statusText.textContent = 'Noch nicht verbunden'
    hint.textContent = 'Geh zuerst auf Vinted und log dich ein.'
  }
})

document.getElementById('btn-settings').addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://truesource-web-pink.vercel.app/settings' })
})

document.getElementById('btn-vinted').addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://www.vinted.de' })
})
