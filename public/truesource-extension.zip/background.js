chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'TOKEN_READY') {
    chrome.action.setBadgeText({ text: '!' })
    chrome.action.setBadgeBackgroundColor({ color: '#14b8a6' })
  }
  if (msg.type === 'CONNECTED') {
    chrome.action.setBadgeText({ text: '✓' })
    chrome.action.setBadgeBackgroundColor({ color: '#22c55e' })
    setTimeout(() => chrome.action.setBadgeText({ text: '' }), 4000)
  }
})
