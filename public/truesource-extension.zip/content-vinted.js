;(function () {
  const match = document.cookie.match(/(?:^|; )access_token_web=([^;]*)/)
  if (!match) return

  const token = decodeURIComponent(match[1])
  const domain = 'www.' + location.hostname.replace(/^www\./, '')

  chrome.storage.local.get('vinted_token', (prev) => {
    if (prev.vinted_token === token) return
    chrome.storage.local.set({ vinted_token: token, vinted_domain: domain, vinted_at: Date.now() })
    chrome.runtime.sendMessage({ type: 'TOKEN_READY', domain })
  })
})()
